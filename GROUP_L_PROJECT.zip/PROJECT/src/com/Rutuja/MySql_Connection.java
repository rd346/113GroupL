package com.Rutuja;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class MySql_Connection {
	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");//load driver class
		String url = "jdbc:mysql://localhost:3306/Eshopping";
		String user = "root";
		String password = "Rutuja@2144";
		Connection con = DriverManager.getConnection(url, user,password);
		String query = "insert into estore values (?,?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(query);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter id>>");
		int id = sc.nextInt();
		System.out.println("Please enter details>>");
		String details = sc.next();
		System.out.println("Please enter pname>>");
		String pname = sc.next();
		System.out.println("Please enter price>>");
		int price = sc.nextInt();
		System.out.println("Please enter quant >>");
		int quant = sc.nextInt();
		
		
		pst.setInt(1, id);
		pst.setString(2,details);
		pst.setString(3, pname);
		pst.setInt(4, price);
		pst.setInt(5, quant);
		// pst.execute();
				int i = pst.executeUpdate();
		
		System.out.println(i+" Row is inserted successfully..");
		
		//close resources
		con.close();
		pst.close();
			
	}

}
