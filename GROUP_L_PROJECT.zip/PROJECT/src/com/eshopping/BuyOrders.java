package com.eshopping;
import OnlineStore.*;


import java.util.ArrayList;
import java.util.Scanner;

import OnlineStore.eStore;

public class BuyOrders {
	public static void main(String[] args) {
		buyList();
	}
	public static void buyList() {
		ArrayList<eStore>pdt=new ArrayList<eStore>();
		Scanner sc= new Scanner(System.in);
		//while(true) {
			System.out.println("Enter the Item Id");
		int input=sc.nextInt();
		
		switch (input) {                  
		case 0 : pdt.add(new eStore(0,"SmartPhones","iphone",150000,90));
		        break;
		case 1 : pdt.add(new eStore(1,"Laptop","Hp",50000,450));
	    break;
		case 2 : pdt.add(new eStore(2,"SmartWatch","iwatch7",90000,330));
	    break;
		case 3 : pdt.add(new eStore(3,"Headphones","Boat",3000,560));	
	    break;
		case 4 :pdt.add(new eStore(4,"Refrigerator","LG",47000,90));
	    break;
		case 5 : pdt.add(new eStore(5,"WashingMachine","Whirlpool",18950,300));
	    break;
		case 6 : pdt.add(new eStore(6,"WaterPurifier","Kent",16450,500));
	    break;
		case 7 : pdt.add(new eStore(7,"LEDTv","Samsung",70000,650));
	    break;
		case 8 : pdt.add(new eStore(8,"AirConditioners","Haier",44000,400));
	    break;
		case 9 : pdt.add(new eStore(9,"Geyser","Bajaj",5000,700));
	    break;
		case 10 : pdt.add(new eStore(10,"SmartPhones","MI",20000,500));
	    break;
		case 11: pdt.add(new eStore(11,"SmartPhones","Oppo",15000,677));
	    break;
		case 12: pdt.add(new eStore(12,"SmartPhones","Oneplus",25000,480));
	    break;
		case 13: pdt.add(new eStore(13,"Laptop","Dell",40000,300));
	    break;
		case 14: pdt.add(new eStore(14,"Laptop","Lenovo",45000,500));
	    break;
		case 15: pdt.add(new eStore(15,"Refrigerator","Godrej",26000,690));
	    break;
		case 16: pdt.add(new eStore(16,"Headphones","JBL",7000,250));
	    break;
		case 17: pdt.add(new eStore(17,"WashingMachine","LG",34000,543));
	    break;
		case 18: pdt.add(new eStore(18,"WashingMachine","Bajaj",28000,230));
	    break;
		case 19: pdt.add(new eStore(19,"SmartWatch","MI",4000,210));
	    break;
		case 20: pdt.add(new eStore(20,"SmartWatch","Boat",2000,530));
	    break;
		case 21: pdt.add(new eStore(21,"AirConditioners","LG",34000,478));
	    break;
		case 22:  pdt.add(new eStore(22,"AirConditioners","Croma",33000,240));
	    break;
		case 23: pdt.add(new eStore(23,"Headphones","Noise",14000,780));
	    break;
		case 24: pdt.add(new eStore(24,"WaterPurifier","Aquaguard",13000,450));
	    break;
		case 25: pdt.add(new eStore(25,"WaterPurifier","Pureit",14999,439));
	    break;
		case 26: pdt.add(new eStore(26,"Geyser","Crompton",7400,450));
	    break;
		case 27: pdt.add(new eStore(27,"Geyser","Sunpoint",21000,760));
	    break;
		case 28: pdt.add(new eStore(28,"LEDTv","MI",23000,450));
	    break;
		case 29: pdt.add(new eStore(29,"LEDTv","Sony",45990,233));
	    break;
		case 30: pdt.add(new eStore(30,"Refrigerator","Haier",45000,670));	
	    break;
	    
		 default: System.out.println("Invalid Id");
		}
		/*int sum=0;
		
		for(eStore e :pdt.get(input).getPrice() ) {
			sum=sum+e;
			 sum;
		}*/
		
		System.out.println("ORDER INVOICE>>");
		System.out.println(pdt);
		
		
		
		
		//}
	}
}

