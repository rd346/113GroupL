package com.eshopping;
import OnlineStore.*; 
import java.util.Scanner;


public class HomepageCode {
	
	public static void resgisteredUser() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the type of customer>>");
		System.out.println("guest\t\tuser\t\tadmin");
		while(true) {
		String input=sc.next();
		
		if(input.equals("guest")) {
		
			//System.out.println("To buy items create account by signing in to the website");
			System.out.println("Welcome to our eStore & explore the world of electronics!!!");
			ItenaryList.itenaryList();
			System.out.println("Enter item ID you want to buy");
			//GuestOrderException.getException(input1);
			  
			  
		}else if(input.equals("user")) {
			System.out.println("Welcome to our eStore. Enter the login details");
			System.out.println("Enter your Firstname");
			String fName=sc.next();
			System.out.println("Enter your lastname");
			String lName=sc.next();
			System.out.println("Enter your username");
			String username=sc.next();
			System.out.println("Enter your password");
			String password=sc.next();
			System.out.println("Enter your city");
			String city=sc.next();
			System.out.println("Enter your email-ID");
			String emailID=sc.next();
			System.out.println("Enter your mob.No");
			long mobNo=sc.nextLong();
			System.out.println();
			User_itenary.userItenary();
			System.out.println();
			System.out.println("Enter 'y' to add to cart");
			String cart=sc.next();
			if(cart.equals("y")) {
				Cart.cartList();
			}
		}else if(input.equals("admin")) {
			System.out.println("Access granted to user details");
			BuyOrders.buyList();
			
		}else {
			System.out.println("invalid input, please write the correct input");
		}
		}
}
	public static void main(String[] args) {
		resgisteredUser();
		
	}
}