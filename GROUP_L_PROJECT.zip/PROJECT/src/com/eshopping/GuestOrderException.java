package com.eshopping;

public class GuestOrderException {
	public static void getException(int input1) {
		try {
			if (input1 >= 0) {
				throw new Guest_Login_Exception("Login as user by google account");
			}
		} catch (RuntimeException e) {
			System.out.println(e);
		}
	}
}


