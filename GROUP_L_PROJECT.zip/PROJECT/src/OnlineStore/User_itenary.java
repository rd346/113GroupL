package OnlineStore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class User_itenary  {

	public static void main(String[] args) {
		userItenary();
	//	sortGeyser();
		
	} public static void userItenary() {
	
		System.out.println("Enter the no. for required electronic item");
		System.out.println("SmartPhone=iphone14==== 0");
		System.out.println("Laptop=HP==== 1");
		System.out.println("Smartwatch=iwatch7===2");
		System.out.println("Headphones=Boat===3");
		System.out.println("Refrigerator=LG===4");
		System.out.println("WashingMachine=Whirlpool===5");
		System.out.println("Waterpurifier=Kent===6");
		System.out.println("LEDTv=Samsung===7");
		System.out.println("Airconditioners=Haier===8");
		System.out.println("Geyser=Bajaj===9");
		System.out.println("SmartPhone=MI====10");
		System.out.println("SmartPhone=Oppo====11");
		System.out.println("SmartPhone=Oneplus====12");
		System.out.println("Laptop=Dell===13");
		System.out.println("Laptop=Lenovo===14");
		System.out.println("Refrigerator=Godrej===15");
		System.out.println("Headphones=JBL===16");
		System.out.println("WashingMachine=LG===17");
		System.out.println("WashingMachine=Bajaj===18");
		System.out.println("Smartwatch=MI===19");
		System.out.println("Smartwatch=Boat===20");
		System.out.println("Airconditioners=LG===21");
		System.out.println("Airconditioners=Croma===22");
		System.out.println("Headphones=Noise===23");
		System.out.println("Waterpurifier=Aquaguard===24");
		System.out.println("Waterpurifier=Pureit===25");
		System.out.println("Geyser=Crompton===26");
		System.out.println("Geyser=Sunpoint===27");
		System.out.println("LEDTv=MI===28");
		System.out.println("LEDTv=Sony===29");
		System.out.println("Refrigerator=Haier===30");
		

		ArrayList<eStore>pdt=new ArrayList<eStore>();
		pdt.add(new eStore(0,"SmartPhones","iphone",150000,90));
		pdt.add(new eStore(1,"Laptop","Hp",50000,450));
		pdt.add(new eStore(2,"SmartWatch","iwatch7",90000,330));
		pdt.add(new eStore(3,"Headphones","Boat",3000,560));
		pdt.add(new eStore(4,"Refrigerator","LG",47000,90));
		pdt.add(new eStore(5,"WashingMachine","Whirlpool",18950,300));
		pdt.add(new eStore(6,"WaterPurifier","Kent",16450,500));
		pdt.add(new eStore(7,"LEDTv","Samsung",70000,650));
		pdt.add(new eStore(8,"AirConditioners","Haier",44000,400));
		pdt.add(new eStore(9,"Geyser","Bajaj",5000,700));
		pdt.add(new eStore(10,"SmartPhones","MI",20000,500));
		pdt.add(new eStore(11,"SmartPhones","Oppo",15000,677));
		pdt.add(new eStore(12,"SmartPhones","Oneplus",25000,480));
		pdt.add(new eStore(13,"Laptop","Dell",40000,300));
		pdt.add(new eStore(14,"Laptop","Lenovo",45000,500));
		pdt.add(new eStore(15,"Refrigerator","Godrej",26000,690));
		pdt.add(new eStore(16,"Headphones","JBL",7000,250));
		pdt.add(new eStore(17,"WashingMachine","LG",34000,543));
		pdt.add(new eStore(18,"WashingMachine","Bajaj",28000,230));
		pdt.add(new eStore(19,"SmartWatch","MI",4000,210));
		pdt.add(new eStore(20,"SmartWatch","Boat",2000,530));
		pdt.add(new eStore(21,"AirConditioners","LG",34000,478));
		pdt.add(new eStore(22,"AirConditioners","Croma",33000,240));
		pdt.add(new eStore(23,"Headphones","Noise",14000,780));
		pdt.add(new eStore(24,"WaterPurifier","Aquaguard",13000,450));
		pdt.add(new eStore(25,"WaterPurifier","Pureit",14999,439));
		pdt.add(new eStore(26,"Geyser","Crompton",7400,450));
		pdt.add(new eStore(27,"Geyser","Sunpoint",21000,760));
		pdt.add(new eStore(28,"LEDTv","MI",23000,450));
		pdt.add(new eStore(29,"LEDTv","Sony",45990,233));
		pdt.add(new eStore(30,"Refrigerator","Haier",45000,670));	
		
		Scanner sc= new Scanner(System.in);
		//while(true) {
		int input=sc.nextInt();

		switch (input) {                  
		case 0 : System.out.println(pdt.get(0));
		break;
		case 1 : System.out.println(pdt.get(1));
	    break;
		case 2 : System.out.println(pdt.get(2));
	    break;
		case 3 : System.out.println(pdt.get(3));
	    break;
		case 4 : System.out.println(pdt.get(4));
	    break;
		case 5 : System.out.println(pdt.get(5));
	    break;
		case 6 : System.out.println(pdt.get(6));
	    break;
		case 7 : System.out.println(pdt.get(7));
	    break;
		case 8 : System.out.println(pdt.get(8));
	    break;
		case 9 : System.out.println(pdt.get(9));
	    break;
		case 10 : System.out.println(pdt.get(10));
	    break;
		case 11: System.out.println(pdt.get(11));
	    break;
		case 12: System.out.println(pdt.get(12));
	    break;
		case 13: System.out.println(pdt.get(13));
	    break;
		case 14: System.out.println(pdt.get(14));
	    break;
		case 15: System.out.println(pdt.get(15));
	    break;
		case 16: System.out.println(pdt.get(16));
	    break;
		case 17: System.out.println(pdt.get(17));
	    break;
		case 18: System.out.println(pdt.get(18));
	    break;
		case 19: System.out.println(pdt.get(19));
	    break;
		case 20: System.out.println(pdt.get(20));
	    break;
		case 21: System.out.println(pdt.get(21));
	    break;
		case 22: System.out.println(pdt.get(22));
	    break;
		case 23: System.out.println(pdt.get(23));
	    break;
		case 24: System.out.println(pdt.get(24));
	    break;
		case 25: System.out.println(pdt.get(25));
	    break;
		case 26: System.out.println(pdt.get(26));
	    break;
		case 27: System.out.println(pdt.get(27));
	    break;
		case 28: System.out.println(pdt.get(28));
	    break;
		case 29: System.out.println(pdt.get(29));
	    break;
		case 30: System.out.println(pdt.get(30));
	    break;
	    
		 default: System.out.println("Invalid input");
		//}
		}
		}/*public static void sortGeyser(){
			ArrayList<eStore>pdt=new ArrayList<eStore>();
			Collections.sort(pdt, new GeyserPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}*/
		
	
	}


