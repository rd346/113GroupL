package OnlineStore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import com.eshopping.Guest_Login_Exception;
public class ItenaryList {
	public static void main(String[] args) {
		itenaryList();
	}
	public static void itenaryList() {
		
		System.out.println("Enter the no. for required electronic item");
		System.out.println("SmartPhone=iphone14==== 0");
		System.out.println("Laptop=HP==== 1");
		System.out.println("Smartwatch=iwatch7===2");
		System.out.println("Headphones=Boat===3");
		System.out.println("Refrigerator=LG===4");
		System.out.println("WashingMachine=Whirlpool===5");
		System.out.println("Waterpurifier=Kent===6");
		System.out.println("LEDTv=Samsung===7");
		System.out.println("Airconditioners=Haier===8");
		System.out.println("Geyser=Bajaj===9");
		System.out.println("SmartPhone=MI====10");
		System.out.println("SmartPhone=Oppo====11");
		System.out.println("SmartPhone=Oneplus====12");
		System.out.println("Laptop=Dell===13");
		System.out.println("Laptop=Lenovo===14");
		System.out.println("Refrigerator=Godrej===15");
		System.out.println("Headphones=JBL===16");
		System.out.println("WashingMachine=LG===17");
		System.out.println("WashingMachine=Bajaj===18");
		System.out.println("Smartwatch=MI===19");
		System.out.println("Smartwatch=Boat===20");
		System.out.println("Airconditioners=LG===21");
		System.out.println("Airconditioners=Croma===22");
		System.out.println("Headphones=Noise===23");
		System.out.println("Waterpurifier=Aquaguard===24");
		System.out.println("Waterpurifier=Pureit===25");
		System.out.println("Geyser=Crompton===26");
		System.out.println("Geyser=Sunpoint===27");
		System.out.println("LEDTv=MI===28");
		System.out.println("LEDTv=Sony===29");
		System.out.println("Refrigerator=Haier===30");

		Guest_Login_Exception.main(null);
			
		//sortAC(pdt);
		
		
/*		Collections.sort(pdt, new AirConditionrsPriceCompare());
		Collections.sort(pdt, new GeyserPriceCompare());
		Collections.sort(pdt, new HeadPhonesPriceCompare());
		Collections.sort(pdt, new LaptopPriceCompare());
		Collections.sort(pdt, new RefrigeratorPriceCompare());
	    Collections.sort(pdt, new SmartPhonesPriceCompare());
		Collections.sort(pdt, new SmartWatchPriceCompare());
		Collections.sort(pdt, new WashingMachinesPriceCompare());
		Collections.sort(pdt, new LEDTvPriceCompare());
		Collections.sort(pdt, new WaterPurifierPriceCompare());
		
		System.out.println("after sorting>>");
	for(eStore p : pdt) {
			System.out.println(p);
	}*/
	
	
	
}
		public static void sortAC(ArrayList pdt){
		ArrayList<eStore>pdtAC=new ArrayList<eStore>(pdt);
       Collections.sort(pdtAC, new AirConditionrsPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdtAC) {
				System.out.println(p);
			}
			
		}
		public static void sortGeyser(){
			ArrayList<eStore>pdt=new ArrayList<eStore>();
			Collections.sort(pdt, new GeyserPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		/*public void sortHeadphones(){
			Collections.sort(pdt, new HeadPhonesPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		public void sortLaptop(){
			Collections.sort(pdt, new LaptopPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		public void sortRefrigerator(){
			Collections.sort(pdt, new RefrigeratorPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		public void sortSmartPhones(){
			Collections.sort(pdt, new SmartPhonesPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		public void sortSmartWatches(){
			Collections.sort(pdt, new SmartWatchPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		public void sortWashingMachines(){
			Collections.sort(pdt, new WashingMachinesPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		public void sortWaterPurifier(){
			Collections.sort(pdt, new WaterPurifierPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
		}
		public void sortLEDTv(){
			Collections.sort(pdt, new LEDTvPriceCompare());
			System.out.println("after sorting>>");
			for(eStore p : pdt) {
				System.out.println(p);
			}
*/	/*	}
	*/			

	}
	

