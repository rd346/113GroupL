package OnlineStore;

public class eStore {
	int id;
	String details;
	String pname;
	static int price;
	int quant;
	
	public eStore(int price) {
		this.price=price;
	}
	public eStore(int id, String details, String pname, int price, int quant) {
		super();
		this.id = id;
		this.details = details;
		this.pname = pname;
		this.price = price;
		this.quant = quant;
	}
    @Override
	public String toString() {
		return "eStore [id=" + id + ", details=" + details + ", pname=" + pname + ", price=" + price + ", quant="
				+ quant + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public static int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}

	

}
