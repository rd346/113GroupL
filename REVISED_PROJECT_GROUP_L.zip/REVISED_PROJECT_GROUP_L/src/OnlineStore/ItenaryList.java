package OnlineStore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import com.eshopping.Guest_Login_Exception;
public class ItenaryList {
	
	public static void main(String[] args) {
		String sp="smartphone";
		String lp="laptop";
		String hp="headphone";
		
	Scanner sc=new Scanner(System.in);
    String input2=sc.next(); 
    
	if(input2.equals(sp.toLowerCase())) {		
		getSmartPhone();
	}
	else if(input2.equals(lp.toLowerCase())){
	    getLaptop();					
	}
	else if(input2.equals(hp.toLowerCase())){
		getHeadPhones();
	}
	else {
		System.err.println("Enter valid option");
	}
	}					 
		public static void getSmartPhone() {
			ArrayList<eStore>pdt1=new ArrayList<eStore>();
			pdt1.add(new eStore(0,"SmartPhones","iphone14",150000,90));
			pdt1.add(new eStore(1,"SmartPhones","MI",20000,500));
			pdt1.add(new eStore(2,"SmartPhones","Oppo",15000,677));
			pdt1.add(new eStore(3,"SmartPhones","Oneplus",25000,480));
			
			Collections.sort(pdt1,new SmartPhonesPriceCompare());
			System.out.println("after sorting acording to price>>");
			//System.out.println(pdt1);
			for(Object i:pdt1){
				System.out.println(i);
			}
			System.out.println();
			System.out.println("Enter item id to add to cart>>");
			
			
				Guest_Login_Exception.main(null);	
			//CUSTOM EXCEPTION FOR NON REGISTERED GUESTS
			
		}
		public static void getLaptop() {
			ArrayList<eStore>pdt2=new ArrayList<eStore>();
			pdt2.add(new eStore(4,"Laptop","Hp",50000,450));
			pdt2.add(new eStore(5,"Laptop","Dell",40000,300));
			pdt2.add(new eStore(6,"Laptop","Lenovo",45000,500));
			
			Collections.sort(pdt2,new LaptopPriceCompare());
			System.out.println("after sorting acording to price>>");
			//System.out.println(pdt2);
			for(Object i:pdt2){
				System.out.println(i);
			}
			System.out.println();
			System.out.println("Enter item id to add to cart>>");
			
			
				Guest_Login_Exception.main(null);
			

		}
		public static void getHeadPhones() {
			ArrayList<eStore>pdt3=new ArrayList<eStore>();
			pdt3.add(new eStore(7,"Headphones","Boat",3000,560));
	        pdt3.add(new eStore(8,"Headphones","JBL",7000,250));		
			pdt3.add(new eStore(9,"Headphones","Noise",14000,780));
			
			Collections.sort(pdt3,new HeadPhonesPriceCompare());
			System.out.println("after sorting acording to price>>"); 
			//System.out.println(pdt3);
			for(Object i:pdt3){
				System.out.println(i);
			}
			System.out.println();
			System.out.println("Enter item id to add to cart>>");
			
			
				Guest_Login_Exception.main(null);	

		
		}
		
}	

	