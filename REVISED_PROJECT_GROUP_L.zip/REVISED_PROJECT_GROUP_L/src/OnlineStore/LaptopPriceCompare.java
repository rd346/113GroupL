package OnlineStore;

import java.util.Comparator;

public class LaptopPriceCompare implements Comparator<eStore> {
	@Override
	public int compare(eStore p1,eStore p2) {
		if(p1.getPrice() == p2.getPrice()) {
			return 0;
		}else if(p2.getPrice()> p1.getPrice()) {
			return 1;
		}else
		return -1;

}

}
