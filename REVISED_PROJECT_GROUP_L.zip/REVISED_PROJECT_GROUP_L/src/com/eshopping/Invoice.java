package com.eshopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Invoice {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");//load driver class
		String url = "jdbc:mysql://localhost:3306/eshopping";
		String user = "root";
		String password = "Shershah1@";
		Connection con = DriverManager.getConnection(url, user,password);
		int total=0;
		String query = "select * from buyOrder";
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=con.prepareStatement(query);
			
			rs=pst.executeQuery();
			System.out.println("\t\tINVOICE>>");
			while(rs.next()) {
				System.out.println("Id>>"+rs.getInt(1));
				System.out.println("Category>>"+rs.getString(2));
				System.out.println("Brand>>"+rs.getString(3));
				System.out.println("Price>>"+rs.getInt(4));
	            total=total+rs.getInt(4);
				System.out.println();
			}
			System.out.println("Total amount= Rs"+total+" only");
			
			DeliveredOrders.main(null);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if (con != null || pst != null || rs!=null) {
				try {
					rs.close();
					con.close();
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}

		

