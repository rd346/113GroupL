package com.eshopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeliveredOrders {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");//load driver class
		String url = "jdbc:mysql://localhost:3306/eshopping";
		String user = "root";
		String password1 = "Shershah1@";
		Connection con = DriverManager.getConnection(url, user,password1);
				
//CREATION OF USER BUY HISTORY DB FOR ADMIN:-
		
		System.out.println("Enter the no. of items to add in buy history>>");
		String query2 ="insert into buyHistory select*from buyOrder where id=?";
	    PreparedStatement pst2 = con.prepareStatement(query2);
		Scanner sc=new Scanner(System.in);
		int noOfItems2 =sc.nextInt();
		if (noOfItems2 > 0) {
			for (int i = 0; i < noOfItems2; i++) {
	
		System.out.println("Enter id of the items to add in buy history>>");
		
		int id=sc.nextInt();
		pst2.setInt(1, id);
		int j = pst2.executeUpdate();
		System.out.println(j + " items added succesfully in buy history");
			}
			}else {
				System.err.println("Enter positive value");
			}
		
		/*FIRST MAKE REQUIRED CHANGES IN PASSWORD AND RUN BELOW QUERY IN SQL:-
		 * create table buyHistory
			(id int,
			category varchar(255),
			brand varchar(255),
			price int);
			select * from buyHistory;*/
		
//DELETION OF DELIVERED ORDERS IN ORDER TO DISPLAY ONLY NEW ORDERS IN INVOICE TO CLIENT:-
		
		System.out.println("All your orders are delivered!!Thank you!!");
		System.out.println("Enter the no. of items delivered>>");
		String query = "delete from buyOrder where id=?";
		PreparedStatement pst = con.prepareStatement(query);
		//Scanner sc=new Scanner(System.in);
		int noOfItems =sc.nextInt();
		if (noOfItems > 0) {
			for (int i = 0; i < noOfItems; i++) {
	
		System.out.println("Enter id of the items that are delivered>>");
		
		int id=sc.nextInt();
		pst.setInt(1, id);
		int j = pst.executeUpdate();
		System.out.println(j + " items delivered succesfully and are removed from live orders list");
		System.out.println();
		System.out.println("For any kind of queries call on tollfree helpline no.-8888899999");
		System.out.println("For continuing shopping enter 'user' or may exit the chatbot..Thanks for shopping with us!! Please visit again!! ");
			}
			}else {
				System.err.println("Enter positive value");
			}
			
		con.close();
		pst.close();
	
}

	}


