package com.eshopping;

public class GuestOrderException {
	public static void getException(int input1) {
		try {
			if (input1 >= 0) {
				throw new Guest_Login_Exception("Enter 'user' below to regster>>");
			}
		} catch (RuntimeException e) {
			System.out.println(e.getMessage());
			System.err.println("First register as user to add items to cart and buy");
		}
	}
}


