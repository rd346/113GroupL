package com.eshopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import OnlineStore.User_itenary;

public class UserDetails {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");//load driver class
		String url = "jdbc:mysql://localhost:3306/eshopping";
		String user = "root";
		String password1 = "Shershah1@";
		Connection con = DriverManager.getConnection(url, user,password1);
		String query = "insert into userDetails values (?,?,?,?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(query);
		
       /*FIRST MAKE REQUIRED CHANGES IN PASSWORD AND RUN BELOW QUERY IN SQL:-
	    *create table userDetails(fName varchar(255),lName varchar(255),username varchar(255),password2 varchar(255),city varchar(255),emailID varchar(255),mobNo long);
	    *select * from userDetails ;*/
			
	Scanner sc= new Scanner(System.in);
	System.out.println("Welcome to our eStore!!!\nEnter the login details>>");
	System.out.println("Enter your Firstname>>");
	String fName=sc.next();
	System.out.println("Enter your lastname>>");
	String lName=sc.next();
	System.out.println("Enter your username>>");
	String username=sc.next();
	System.out.println("Enter your password>>");
	String password2=sc.next();
	System.out.println("Enter your city>>");
	String city=sc.next();
	System.out.println("Enter your email-ID>>");
	String emailID=sc.next();
	System.out.println("Enter your mobile No.>>");
	long mobNo=sc.nextLong();
	System.out.println();
	
	pst.setString(1,fName);
	pst.setString(2,lName);
	pst.setString(3,username);
	pst.setString(4,password2);
	pst.setString(5,city);
	pst.setString(6,emailID);
	if(mobNo>=6000000000l) {  //VALIDATION OF NO.
	pst.setLong(7,mobNo);
	}else {
		System.err.println("Enter a valid 10 digits no.");
	}
	int i = pst.executeUpdate();
	
	System.out.println(i+" Row is inserted successfully..");
	
	con.close();
	pst.close();
		
	User_itenary.userItenary();
}
}
