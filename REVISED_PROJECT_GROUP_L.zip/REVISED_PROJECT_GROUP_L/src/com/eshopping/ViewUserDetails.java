package com.eshopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewUserDetails {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");//load driver class
		String url = "jdbc:mysql://localhost:3306/eshopping";
		String user = "root";
		String password = "Shershah1@";
		Connection con = DriverManager.getConnection(url, user,password);
		
		String query = "select fName,lname,username,city,emailId,mobNo from userDetails";
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=con.prepareStatement(query);
			
			rs=pst.executeQuery();
			System.out.println("\t\tUSER DETAILS>>");
			while(rs.next()) {
				System.out.println("First Name>>"+rs.getString(1));
				System.out.println("Last Name>>"+rs.getString(2));
				System.out.println("Username>>"+rs.getString(3));
				System.out.println("City>>"+rs.getString(4));
				System.out.println("Mail Id>>"+rs.getString(5));
				//System.out.println("Passsword>>"+rs.getString(6));
				System.out.println("Contact no.>>"+rs.getLong(6));
	           
				System.out.println();
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if (con != null || pst != null || rs!=null) {
				try {
					rs.close();
					con.close();
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}

		




