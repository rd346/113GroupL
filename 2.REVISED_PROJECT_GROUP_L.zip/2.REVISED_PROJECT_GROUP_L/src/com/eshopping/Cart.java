package com.eshopping;
import OnlineStore.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import OnlineStore.eStore;

public class Cart {
	//static int j;
		public static void main(String[] args) throws ClassNotFoundException,SQLException{
			Class.forName("com.mysql.cj.jdbc.Driver");//load driver class
			String url = "jdbc:mysql://localhost:3306/eshopping";
			String user = "root";
			String password = "Shershah1@";
			Connection con = DriverManager.getConnection(url, user,password);
			
			/*FIRST MAKE REQUIRED CHANGES IN PASSWORD AND RUN BELOW QUERY IN SQL:-
			 *create database eshopping;
				use eshopping;
				create table itenary
				(id int,
				category varchar(255),
				brand varchar(255),
				price int,
				stock int);
				select * from itenary;
				desc itenary;
				insert into itenary values
	            (0,"SmartPhones","iphone14",150000,90),
				(1,"SmartPhones","MI",20000,500),
				(2,"SmartPhones","Oppo",15000,677),
	            (3,"SmartPhones","Oneplus",25000,480),
	            (4,"Laptop","Hp",50000,450),
				(5,"Laptop","Dell",40000,300),
				(6,"Laptop","Lenovo",45000,500),
	            (7,"Headphones","Boat",3000,560),
		        (8,"Headphones","JBL",7000,250),		
				(9,"Headphones","Noise",14000,780);
				alter table itenary drop stock ; 
				create table cart
				(id int,
				category varchar(255),
				brand varchar(255),
				price int);
				select * from cart;
			 */
			
			String query = "insert into cart select *from itenary where id=?";
			PreparedStatement pst = con.prepareStatement(query);
			
			System.out.println("How many items you want to add to cart?");
			Scanner sc = new Scanner(System.in);
			int noOfItems = sc.nextInt();
			
			if (noOfItems > 0) {
				for (int i = 0; i < noOfItems; i++) {
					
		 System.out.println("Enter item id>>");
		 int itemId=sc.nextInt();
	     
		 
		    pst.setInt(1, itemId);
			
			int j = pst.executeUpdate();
			
			System.out.println(j+" item added to cart successfully..");
				}
		}else {System.err.println("Enter only positive value next time ..\\nNow enter 'user' again>>");
		}
			//close resources
			con.close();
			pst.close();
		
			Buy.main(null);
	}
}