package com.eshopping;

public class GuestOrderException {
	public static void getException(int input1) {
		try {
			if (input1 >= 0) {
				throw new Guest_Login_Exception("\nEnter 'user' below to regster>>");
			}
		} catch (RuntimeException e) {
			System.err.println("\nFirst register as user to add items to cart and then to buy>>");
			System.out.println(e.getMessage());
		}
	}
}


