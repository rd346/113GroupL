package com.eshopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Buy {
	
	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/eshopping";
		String user = "root";
		String password = "Shershah1@";
		Connection con = DriverManager.getConnection(url, user,password);
		
		/*FIRST MAKE REQUIRED CHANGES IN PASSWORD AND RUN BELOW QUERY IN SQL:-
		 * create table buyOrder
			(id int,
			category varchar(255),
			brand varchar(255),
			price int);
		 */
		String query = "insert into buyOrder select*from cart where id=?";
		PreparedStatement pst = con.prepareStatement(query);
		
		System.out.println("How many items you want to add to buy order?");
		Scanner sc = new Scanner(System.in);
		int noOfItems = sc.nextInt();
		
		if (noOfItems > 0) {
			for (int i = 0; i < noOfItems; i++) {
	
	System.out.println("Enter item id to place the order>>");
    int id=sc.nextInt();
    pst.setInt(1, id);
    int j = pst.executeUpdate();
	
	System.out.println(j+" item added to buy order successfully..");
			}
			
		Invoice.main(null);
			
			}else {
				System.err.println("Enter only positive value next time ..\nNow enter 'user' again>>");
			}
			
				
				con.close();
				pst.close();
			
			}
		}
	