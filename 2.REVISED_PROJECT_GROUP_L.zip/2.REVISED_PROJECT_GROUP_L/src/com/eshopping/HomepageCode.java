package com.eshopping;
import OnlineStore.*;
import java.sql.SQLException;
import java.util.Scanner;

//THIS IS THE MAIN CLASS, RUN FROM HERE:-

public class HomepageCode {
	
	public static void resgisteredUser() {
		String gst="guest";
		String usr="user";
		String adm="admin";
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the type of customer>>");
		System.out.println();
		System.out.println("\t\t'guest'\t\t'user'\t\t'admin'");
		System.out.println();
		
		while(true) {
		String input=sc.next();
		    //guest case
		if(input.toLowerCase().equals(gst)) {     
		System.out.println("Welcome to our eStore & explore the world of electronics!!!");
		System.out.println("\nEnter the item name that you want to explore");
		System.out.println("\n\t\t'smartphone'\t\t'laptop'\t\t'headphone'");
		
		ItenaryList.main(null);
		}
			//user case
		else if(input.toLowerCase().equals(usr)) {   
			try {
				UserDetails.main(null);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			//admin case
		}else if(input.toLowerCase().equals(adm)) {   
			System.out.println("Access granted to user details");
			try {
				ViewUserDetails.main(null);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				System.out.println();
				BuyHistory.main(null);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			System.err.println("Invalid input, please enter the correct input!!");
		}
		}		
		
}
	public static void main(String[] args) {
		resgisteredUser();
		
	}
}