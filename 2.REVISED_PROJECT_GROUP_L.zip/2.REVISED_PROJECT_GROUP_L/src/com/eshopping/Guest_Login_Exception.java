package com.eshopping;

import java.util.Scanner;

public class Guest_Login_Exception extends RuntimeException{
	public Guest_Login_Exception(String message) {
		super(message);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int input1=sc.nextInt();
		GuestOrderException goe=new GuestOrderException();
		goe.getException(input1);
			
		}
	
}
